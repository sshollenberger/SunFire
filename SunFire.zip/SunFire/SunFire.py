bl_info = {
    "name": "SunFire Skybox",
    "author": "Sean S",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Create Tab",
    "description": "Add a Procedural Skybox",
    "warning": "",
    "doc_url": "",
    "category": "Lighting",
}
import bpy
#import addon_utils
import os
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty
from bpy.types import (
        Operator,
        Panel,
        )
        
def check_world_name(name_id="SunFire"):
    # check if the new name pattern is in world data
    name_list = []
    suffix = 1
    try:
        name_list = [world.name for world in bpy.data.worlds if name_id in world.name]
        new_name = "{}_{}".format(name_id, len(name_list) + suffix)
        if new_name in name_list:
            # KISS failed - numbering is not sequential
            # try harvesting numbers in world names, find the rightmost ones
            test_num = []
            from re import findall
            for words in name_list:
                test_num.append(findall("\d+", words))

            suffix += max([int(l[-1]) for l in test_num])
            new_name = "{}_{}".format(name_id, suffix)
        return new_name
    except Exception as e:
        error_handlers(False, e)
        pass
    return name_id

def read_some_data(context, filepath, node_name):
    #print("running read_some_data...")
    moon = bpy.context.scene.world.node_tree.nodes[node_name]
    
    moon.image=bpy.data.images.load(filepath)
    
    return {'FINISHED'}        

class SunFire(Operator):
    bl_idname = "sky.sunfire"
    bl_label = "Make a Procedural sky"
    bl_description = ("Make a Procedural Sky with parameters in the 3D View\n"
                      "Only the last created SunFire World can be accessed from this panel")

    def get_node_types(self, node_tree, node_type):
        for node in node_tree.nodes:
            if node.type == node_type:
                return node
        return None

    def execute(self, context):
        try:
            #Location of the addon
            d = bpy.utils.user_resource('SCRIPTS', "addons")+"/SunFire/"
            #hackish way to remove .config
            remove="/.config"
            d = d.replace(remove,"")      
            
            get_name = check_world_name()
            context.scene.sunfire_sky_name = get_name
            bpy.context.scene.eevee.use_bloom = True

            world = bpy.data.worlds.new(get_name)
            world.use_nodes = True
            nt = world.node_tree
            ntl = nt.links.new
            tcor = nt.nodes.new(type="ShaderNodeTexCoord")
            tcor.location = (-3620,620)
            
            #SKY LAYER
            skynor = nt.nodes.new(type="ShaderNodeNormal")
            skynor.label = "Sky Normal"
            skynor.location = (-2840, 920)
            skygrad= nt.nodes.new(type="ShaderNodeTexGradient")
            skygrad.location = (-2560, 920)
            skyramp=nt.nodes.new(type="ShaderNodeValToRGB")
            skyramp.location = (-2140, 920)
            skyramp.name = "Sky_Ramp"
            skyramp.color_ramp.elements.new(0.5)
            skyramp.color_ramp.elements.new(0.5)
            skyramp.color_ramp.elements[0].position = 0
            skyramp.color_ramp.elements[1].position = 0.05
            skyramp.color_ramp.elements[2].position = 0.22
            skyramp.color_ramp.elements[3].position = 1
            skyramp.color_ramp.elements[0].color = (0.010421, 0.005222, 0.002959, 1)
            skyramp.color_ramp.elements[1].color = (0.66, 0.692, 1, 1)
            skyramp.color_ramp.elements[2].color = (0.189, 0.345, 1, 1)
            skyramp.color_ramp.elements[3].color = (0, 0.017, 0.129, 1)
            skymix = nt.nodes.new(type="ShaderNodeMixRGB")
            skymix.location = (-1320, 780)
            skymix.label = "Sky Mix"
            skymix.blend_type = 'SCREEN'
            ntl(skynor.inputs[0], tcor.outputs[0])
            ntl(skygrad.inputs[0], skynor.outputs[1])
            ntl(skyramp.inputs[0], skygrad.outputs[0])
            ntl(skymix.inputs[1], skyramp.outputs[0])
            #STARS LAYER
            starmap = nt.nodes.new(type="ShaderNodeMapping")
            starmap.location = (-2980, 680)
            starvn = nt.nodes.new(type="ShaderNodeTexVoronoi")
            starvn.location = (-2560, 680)
            starvn.name = "Star_scale"
            starvn.inputs[2].default_value = 80.6
            starramp=nt.nodes.new(type="ShaderNodeValToRGB")
            starramp.location = (-2140, 680)
            starramp.color_ramp.elements[0].position = 0
            starramp.color_ramp.elements[1].position = 0.109
            starramp.color_ramp.elements[0].color = (1, 1, 1, 1)
            starramp.color_ramp.elements[1].color = (0, 0, 0, 1)
            starrange=nt.nodes.new(type="ShaderNodeMapRange")
            starrange.location = (-1800, 680)
            starrange.inputs[4].default_value = 4
            starmix = nt.nodes.new(type="ShaderNodeMixRGB")
            starmix.location = (-1540, 680)
            starmix.label = "Star Toggle"
            starmix.name = "Star_toggle"
            starmix.blend_type = 'MIX'
            starmix.inputs[0].default_value = 0
            starmix.inputs[1].default_value = (0, 0, 0, 1)
            ntl(starmap.inputs[0], tcor.outputs[0])
            ntl(starvn.inputs[0], starmap.outputs[0])
            ntl(starramp.inputs[0], starvn.outputs[0])
            ntl(starrange.inputs[0], starramp.outputs[0])
            ntl(starmix.inputs[2], starrange.outputs[0])
            ntl(skymix.inputs[0], starmix.outputs[0])
            ntl(skymix.inputs[2], starramp.outputs[0])
            #SUN LAYER
            sunmap1 = nt.nodes.new(type="ShaderNodeMapping")
            sunmap1.location = (-2700, 420)
            sunmap1.name = "Sun_vector"
            sunmap1.inputs[2].default_value[1] = 40.24
            sunmap1.inputs[2].default_value[2] = 12.7
            sunmap2 = nt.nodes.new(type="ShaderNodeMapping")
            sunmap2.location = (-2360, 420)
            sunmap2.inputs[3].default_value[0] = 0.4
            sunmap2.inputs[3].default_value[1] = 0.8
            sunmap3 = nt.nodes.new(type="ShaderNodeMapping")
            sunmap3.location = (-2360, 0)
            sunmap3.inputs[3].default_value[0] = 0.3
            sunmap3.inputs[3].default_value[1] = 3.4
            sunmap3.inputs[3].default_value[2] = 3.4
            sungrad = nt.nodes.new(type="ShaderNodeTexGradient")
            sungrad.location = (-2140, 0)
            sungrad.gradient_type='SPHERICAL'
            sunrange1=nt.nodes.new(type="ShaderNodeMapRange")
            sunrange1.location = (-1760, 380)
            sunrange1.name = "Sun_halo"
            sunrange1.inputs[2].default_value = 0.6
            sunrange1.inputs[4].default_value = 2.9
            sunrange2=nt.nodes.new(type="ShaderNodeMapRange")
            sunrange2.location = (-1600, 0)
            sunrange2.name = "Sun_ambient"
            sunrange2.inputs[4].default_value = 164.9
            sunramp1=nt.nodes.new(type="ShaderNodeValToRGB")
            sunramp1.location = (-1920, 0)
            sunramp1.color_ramp.elements[0].position = 0.68209
            sunramp1.color_ramp.elements[1].position = 0.690909
            sunramp1.color_ramp.elements[0].color = (0, 0, 0, 1)
            sunramp1.color_ramp.elements[1].color = (0.895, 0.795, 0.077, 1)
            sunenv = nt.nodes.new('ShaderNodeTexEnvironment')
            sunenv.location = (-2100,380)
            sunenv.name = "Sun_env"
            try: sunenv.image=bpy.data.images.load(d+"flarehdri.jpeg")
            except:
                print("Unable to load Sun Halo Texture")
                
            sunmix1 = nt.nodes.new(type="ShaderNodeMixRGB")
            sunmix1.location = (-1360, 360)
            sunmix1.blend_type = 'ADD'
            sunmix1.inputs[0].default_value = 1
            sunmix2 = nt.nodes.new(type="ShaderNodeMixRGB")
            sunmix2.location = (-1120, 480)
            sunmix2.blend_type = 'COLOR'
            sunmix2.inputs[0].default_value = 1
            sunmix2.inputs[2].default_value = (1, 1, 1, 1)
            sunmix2.name = "Sun_color"
            sunmix2.label = "Sun_color"
            sunmix3 = nt.nodes.new(type="ShaderNodeMixRGB")
            sunmix3.location = (-880, 640)
            sunmix3.label = "Sun Toggle"
            sunmix3.name = "Sun_Toggle"
            sunmix3.blend_type = 'ADD'
            sunmix3.inputs[0].default_value = 1
            sunmix4 = nt.nodes.new(type="ShaderNodeMixRGB")
            sunmix4.location = (-1640, 160)
            sunmix4.inputs[1].default_value = (0, 0, 0, 1)
            ntl(sunmap1.inputs[0], starmap.outputs[0])
            ntl(sunmap2.inputs[0], sunmap1.outputs[0])
            ntl(sunmap3.inputs[0], sunmap1.outputs[0])
            ntl(sunenv.inputs[0], sunmap2.outputs[0])
            ntl(sunrange1.inputs[0], sunenv.outputs[0])
            ntl(sunmix1.inputs[2], sunrange1.outputs[0])
            ntl(sunmix2.inputs[1], sunmix1.outputs[0])
            ntl(sunmix3.inputs[2], sunmix2.outputs[0])
            ntl(sunmix3.inputs[1], skymix.outputs[0])
            ntl(sungrad.inputs[0], sunmap3.outputs[0])
            ntl(sunramp1.inputs[0], sungrad.outputs[0])
            ntl(sunmix4.inputs[2], sunramp1.outputs[0])
            ntl(sunrange2.inputs[0], sunmix4.outputs[0]) 
            ntl(sunmix1.inputs[1], sunrange2.outputs[0])
            #MOON LAYER
            moonmap1 = nt.nodes.new(type="ShaderNodeMapping")
            moonmap1.location = (-2720, -320)
            moonmap1.name = "Moon_vector"
            moonmap1.inputs[2].default_value[1] = 20.1
            moonmap1.inputs[2].default_value[2] = 8.6
            moonmap2 = nt.nodes.new(type="ShaderNodeMapping")
            moonmap2.location = (-2480, -320)
            moonmap2.inputs[3].default_value[0] = 0.2
            moonmap2.inputs[3].default_value[1] = 0.7
            moonenv = nt.nodes.new('ShaderNodeTexEnvironment')
            moonenv.location = (-2120,-320)
            moonenv.name="Moon_env"
            try: moonenv.image=bpy.data.images.load(d+"moonhdri.jpeg")
            except:
                print("Unable to load Moon Texture")
            moonrange=nt.nodes.new(type="ShaderNodeVectorMath")
            moonrange.location = (-1660, -320)
            moonrange.operation = "MULTIPLY"
            moonsnap = nt.nodes.new('ShaderNodeMath')
            moonsnap.location = (-1940,-560)
            moonsnap.operation = "SNAP"
            moonsnap.label = "Moon Toggle"
            moonsnap.name = "Moon_toggle"
            moonsnap.inputs[0].default_value = 1
            moonsnap.inputs[1].default_value = 0.1
            moonmix = nt.nodes.new(type="ShaderNodeMixRGB")
            moonmix.location = (-520, 460)
            moonmix.blend_type = 'ADD'
            moonmix.inputs[0].default_value = 1
            ntl(moonmap1.inputs[0], tcor.outputs[0])
            ntl(moonmap2.inputs[0], moonmap1.outputs[0])
            ntl(moonenv.inputs[0], moonmap2.outputs[0])
            ntl(moonrange.inputs[0], moonenv.outputs[0])
            ntl(moonrange.inputs[1], moonsnap.outputs[0])
            ntl(moonmix.inputs[2], moonrange.outputs[0])
            ntl(moonmix.inputs[1], sunmix3.outputs[0])
            #PLANET LAYER
            planetmap1 = nt.nodes.new(type="ShaderNodeMapping")
            planetmap1.location = (-2920, -1540)
            planetmap1.name = "Planet_vector"
            planetmap1.inputs[2].default_value[1] = 20.1
            planetmap1.inputs[2].default_value[2] = 8.6
            planetmap2 = nt.nodes.new(type="ShaderNodeMapping")
            planetmap2.location = (-2680, -1540)
            planetmap2.inputs[3].default_value[0] = 0.2
            planetmap2.inputs[3].default_value[1] = 0.7
            planetenv = nt.nodes.new('ShaderNodeTexEnvironment')
            planetenv.location = (-2320,-1540)
            planetenv.name="Planet_env"
            try: planetenv.image=bpy.data.images.load(d+"moonhdri.jpeg")
            except:
                print("Unable to load Planet Texture")
            planetrange=nt.nodes.new(type="ShaderNodeVectorMath")
            planetrange.location = (-1860, -1540)
            planetrange.operation = "MULTIPLY"
            planetsnap = nt.nodes.new('ShaderNodeMath')
            planetsnap.location = (-2040,-1700)
            planetsnap.operation = "SNAP"
            planetsnap.label = "Planet Toggle"
            planetsnap.name = "Planet_toggle"
            planetsnap.inputs[0].default_value = 0
            planetsnap.inputs[1].default_value = 0.1
            planetmix = nt.nodes.new(type="ShaderNodeMixRGB")
            planetmix.location = (-300, 660)
            planetmix.blend_type = 'ADD'
            planetmix.inputs[0].default_value = 1
            ntl(planetmap1.inputs[0], tcor.outputs[0])
            ntl(planetmap2.inputs[0], planetmap1.outputs[0])
            ntl(planetenv.inputs[0], planetmap2.outputs[0])
            ntl(planetrange.inputs[0], planetenv.outputs[0])
            ntl(planetrange.inputs[1], planetsnap.outputs[0])
            ntl(planetmix.inputs[2], planetrange.outputs[0])
            ntl(planetmix.inputs[1], moonmix.outputs[0])
            #CLOUD LAYER
            cloudsep = nt.nodes.new(type="ShaderNodeSeparateRGB")
            cloudsep.location = (-3400, -780)
            cloudmath = nt.nodes.new(type="ShaderNodeMath")
            cloudmath.location = (-3180, -740)
            cloudmath.name = "Cloud_translate"
            cloudmath.operation = 'ADD'
            cloudmath.inputs[0].default_value = 0.2
            cloudcom = nt.nodes.new(type="ShaderNodeCombineRGB")
            cloudcom.location = (-2960, -780)
            cloudmap = nt.nodes.new(type="ShaderNodeMapping")
            cloudmap.location = (-2760, -780)
            cloudmap.inputs[2].default_value[1] = 1.570796
            cloudmap.inputs[3].default_value[0] = 1.5
            cloudmap.inputs[3].default_value[1] = 1.5
            cloudmap.inputs[3].default_value[2] = 6
            cloudnoise1 = nt.nodes.new(type="ShaderNodeTexNoise")
            cloudnoise1.location = (-2500, -740)
            cloudnoise1.inputs[2].default_value = 3.5
            cloudnoise1.inputs[3].default_value = 4.6
            cloudnoise1.inputs[4].default_value = 0.5
            cloudnoise1.inputs[5].default_value = 0.2
            cloudnoise2 = nt.nodes.new(type="ShaderNodeTexNoise")
            cloudnoise2.location = (-2500, -1000)
            cloudnoise2.name = "Cloud_Noise"
            cloudnoise2.inputs[2].default_value = 2
            cloudnoise2.inputs[3].default_value = 10
            cloudnoise2.inputs[4].default_value = 0.5
            cloudnoise2.inputs[5].default_value = 0.25
            cloudgrad= nt.nodes.new(type="ShaderNodeTexGradient")
            cloudgrad.location = (-2500, -1300)
            cloudramp1=nt.nodes.new(type="ShaderNodeValToRGB")
            cloudramp1.location = (-2220, -740)
            cloudramp1.color_ramp.elements[0].position = 0.213636
            cloudramp1.color_ramp.elements[1].position = 0.6
            cloudramp1.color_ramp.elements[0].color = (0, 0, 0, 1)
            cloudramp1.color_ramp.elements[1].color = (1, 1, 1, 1)
            cloudrange1=nt.nodes.new(type="ShaderNodeMapRange")
            cloudrange1.location = (-2160, -1000)
            cloudrange1.inputs[3].default_value = 1.7
            cloudrange1.inputs[4].default_value = -1.2
            cloudrange1.label = "Cloud Thickness"
            cloudrange1.name = "Cloud_thickness"
            cloudrange2=nt.nodes.new(type="ShaderNodeMapRange")
            cloudrange2.location = (-2160, -1300)
            cloudrange2.label = "Horizon Line"
            cloudmix1 = nt.nodes.new(type="ShaderNodeMixRGB")
            cloudmix1.location = (-1840, -1040)
            cloudmix1.inputs[1].default_value = (0, 0, 0, 1)
            cloudramp2=nt.nodes.new(type="ShaderNodeValToRGB")
            cloudramp2.location = (-1600, -840)
            cloudramp2.name = "Cloud_color"
            cloudramp2.label = "Cloud_color"
            cloudramp2.color_ramp.elements[0].position = 0
            cloudramp2.color_ramp.elements[1].position = 0.663636
            cloudramp2.color_ramp.elements[0].color = (0, 0, 0, 0)
            cloudramp2.color_ramp.elements[1].color = (1, 0.672, 0.985, 1)
            cloudmix2 = nt.nodes.new(type="ShaderNodeMixRGB")
            cloudmix2.location = (-1240, -680)
            cloudmix2.blend_type = 'MULTIPLY'
            cloudmix2.label = "Shadow Strength"
            cloudmix2.inputs[0].default_value = 1
            cloudmix3 = nt.nodes.new(type="ShaderNodeMixRGB")
            cloudmix3.location = (-140, 300)
            ntl(cloudsep.inputs[0], tcor.outputs[0])
            ntl(cloudmath.inputs[1], cloudsep.outputs[0])
            ntl(cloudcom.inputs[0], cloudmath.outputs[0])
            ntl(cloudcom.inputs[1], cloudsep.outputs[1])
            ntl(cloudcom.inputs[2], cloudsep.outputs[2])
            ntl(cloudmap.inputs[0], cloudcom.outputs[0])
            ntl(cloudnoise1.inputs[0], cloudmap.outputs[0])
            ntl(cloudnoise2.inputs[0], cloudmap.outputs[0])
            ntl(cloudgrad.inputs[0], cloudmap.outputs[0])
            ntl(cloudramp1.inputs[0], cloudnoise1.outputs[0])
            ntl(cloudrange1.inputs[0], cloudnoise2.outputs[0])
            ntl(cloudrange2.inputs[0], cloudgrad.outputs[0])
            ntl(cloudmix1.inputs[0], cloudrange2.outputs[0])
            ntl(cloudmix1.inputs[2], cloudrange1.outputs[0])
            ntl(cloudramp2.inputs[0], cloudmix1.outputs[0])
            ntl(cloudmix2.inputs[1], cloudramp2.outputs[0])
            ntl(cloudmix2.inputs[2], cloudramp1.outputs[0])
            ntl(cloudmix3.inputs[2], cloudmix2.outputs[0])
            ntl(cloudmix3.inputs[0], cloudramp2.outputs[1])
            ntl(cloudmix3.inputs[1], planetmix.outputs[0])
            ntl(sunmix4.inputs[0], cloudrange2.outputs[0])
            bg = self.get_node_types(nt, "BACKGROUND")
            ntl(bg.inputs[0], cloudmix3.outputs[0])

        except Exception as e:
            error_handlers(self, e, "Make a Procedural sky has failed")

            return {"CANCELLED"}

        return {'FINISHED'}
    
# Handle error notifications
def error_handlers(self, error, reports="ERROR"):
    if self and reports:
        self.report({'WARNING'}, reports + " (See Console for more info)")

    print("\n[SunFire Sky]\nError: {}\n".format(error))

def draw_world_settings(col, context, self):
    get_world = context.scene.world
    stored_name = context.scene.sunfire_sky_name
    get_world_keys = bpy.data.worlds.keys()
        
    if stored_name not in get_world_keys or len(get_world_keys) < 1:
        col.label(text="The {} World could not".format(stored_name), icon="INFO")
        col.label(text="be found in the Worlds' Data", icon="BLANK1")
        return

    elif not (get_world and get_world.name == stored_name):
        col.label(text="Please select the World", icon="INFO")
        col.label(text="named {}".format(stored_name), icon="BLANK1")
        col.label(text="from the Properties > World", icon="BLANK1")
        return

    pick_world = bpy.data.worlds[stored_name]
    try:
        sv = pick_world.node_tree.nodes['Sun_vector'].inputs[2]
        st = pick_world.node_tree.nodes['Sun_Toggle'].inputs[0]
        sc = pick_world.node_tree.nodes['Sun_color'].inputs[2]
        sa = pick_world.node_tree.nodes['Sun_ambient'].inputs[3]
        sd = pick_world.node_tree.nodes['Sun_ambient'].inputs[4]
        sh = pick_world.node_tree.nodes['Sun_halo'].inputs[4]
        cr = pick_world.node_tree.nodes['Sky_Ramp']
        cc = pick_world.node_tree.nodes['Cloud_color'].color_ramp.elements[1]
        ct = pick_world.node_tree.nodes['Cloud_translate'].inputs[0]
        cmin = pick_world.node_tree.nodes['Cloud_thickness'].inputs[3]
        cmax = pick_world.node_tree.nodes['Cloud_thickness'].inputs[4]
        cw = pick_world.node_tree.nodes['Cloud_Noise'].inputs[5]
        cs = pick_world.node_tree.nodes['Cloud_Noise'].inputs[2]
        s = pick_world.node_tree.nodes['Star_toggle'].inputs[0]
        v = pick_world.node_tree.nodes['Star_scale'].inputs[2]
        m = pick_world.node_tree.nodes['Moon_toggle'].inputs[0]
        mv = pick_world.node_tree.nodes['Moon_vector'].inputs[2]
        p = pick_world.node_tree.nodes['Planet_toggle'].inputs[0]
        pv = pick_world.node_tree.nodes['Planet_vector'].inputs[2]

    except:
        col.label(text="Please Create a new World", icon="INFO")
        col.label(text="seems that there was already", icon="BLANK1")
        col.label(text="one called {}".format(stored_name), icon="BLANK1")
        return
    #Panel UI elements
    col.label(text="World: %s" % stored_name)
    col.separator()
    col.label(text="Scene Control")
    
    layout = self.layout
    obj = context.object
    box = layout.box()

    row = box.row()
    row.prop(obj, "expanded1",
        icon="TRIA_DOWN" if obj.expanded1 else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Horizon")
    if obj.expanded1:
        row = box.row()
        row.template_color_ramp(cr, "color_ramp", expand=True)
        
    row = box.row()
    row.prop(obj, "expanded2",
        icon="TRIA_DOWN" if obj.expanded2 else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Clouds")
    if obj.expanded2:
        row = box.row(align=True)
        row.prop(cc, "color", text="Cloud Color")
        row=box.row()
        row.label(text="Minimum Value")
        row.prop(cmin, "default_value", text="")
        row=box.row()
        row.label(text="Maximum Value")
        row.prop(cmax, "default_value", text="")
        row=box.row()
        row.label(text="Cloud Scale")
        row.prop(cs, "default_value", text="")
        row=box.row()
        row.label(text="Wispiness")
        row.prop(cw, "default_value", text="")
        row=box.row()
        row.label(text="Translate")
        row.prop(ct, "default_value", text="")
        
    row = box.row()
    row.prop(obj, "expanded3",
        icon="TRIA_DOWN" if obj.expanded3 else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Sun")
    if obj.expanded3:
        row = box.row()
        row.label(text="Sun Halo")
        props = row.operator("import.node_texture", icon='MAT_SPHERE_SKY')
        props.target = "Sun_env"
        row = box.row()
        row.prop(sc, "default_value", text="Sun Color")
        row = box.row()
        row.prop(sa, "default_value", text="Sun Ambient")
        row = box.row()
        row.prop(sh, "default_value", text="Halo Brightness")
        row = box.row()
        row.prop(sd, "default_value", text="Disc Brightness")
        row = box.row()
        row.prop(st, "default_value", text="Sun Toggle")
        row = box.row()
        row.prop(sv, "default_value", text="Sun Vector")
        
    row = box.row()
    row.prop(obj, "expanded4",
        icon="TRIA_DOWN" if obj.expanded4 else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Moon")
    if obj.expanded4:
        row = box.row()
        props = row.operator("import.node_texture", icon='MAT_SPHERE_SKY')
        props.target = "Moon_env"
        row = box.row()
        row.prop(m, "default_value", text="Brightness")
        row = box.row()
        row.prop(mv, "default_value", text="Moon Vector")
        
    row = box.row()
    row.prop(obj, "expanded5",
        icon="TRIA_DOWN" if obj.expanded5 else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Stars")
    if obj.expanded5:
        row = box.row()
        row.prop(s, "default_value", text="Star Brightness")
        row = box.row()
        row.prop(v, "default_value", text="Star Scale")
        
    row = box.row()
    row.prop(obj, "expanded6",
        icon="TRIA_DOWN" if obj.expanded6 else "TRIA_RIGHT",
        icon_only=True, emboss=False
    )
    row.label(text="Planet")
    if obj.expanded6:
        row = box.row()
        props = row.operator("import.node_texture", icon='MAT_SPHERE_SKY')
        props.target = "Planet_env"
        row = box.row()
        row.prop(p, "default_value", text="Brightness")
        row = box.row()
        row.prop(pv, "default_value", text="Planet Vector")

class SunFirePanel(Panel):
    bl_label = "SunFire"
    bl_idname = "SUNFIRE_PT_Tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = "objectmode"
    bl_category = "Create"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.operator("sky.sunfire", text="Create Sky", icon='MAT_SPHERE_SKY')
        col = layout.column()
        draw_world_settings(col, context, self)

class Import_OT_NodeTexture(Operator, ImportHelper):
    bl_label = "Import HDRI Texture"
    bl_idname = "import.node_texture"
    
    target: StringProperty(
        name="Texture",
        default="Moon_env"
        )
    
    # ImportHelper mixin class uses this
    filename_ext = ".jpeg"
    filter_glob: StringProperty(
        default='*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp',
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )
    
    def execute(self, context):
        return read_some_data(context, self.filepath, self.target)



blender_classes = {
    SunFire,
    SunFirePanel,
    Import_OT_NodeTexture,
}


def register():
    for blender_class in blender_classes:
        bpy.utils.register_class(blender_class)
    bpy.types.Scene.sunfire_sky_name = StringProperty(
        name="",
        default="SunFire"
        )
    bpy.types.Object.expanded1 = bpy.props.BoolProperty(default=False)
    bpy.types.Object.expanded2 = bpy.props.BoolProperty(default=False)
    bpy.types.Object.expanded3 = bpy.props.BoolProperty(default=False)
    bpy.types.Object.expanded4 = bpy.props.BoolProperty(default=False)
    bpy.types.Object.expanded5 = bpy.props.BoolProperty(default=False)
    bpy.types.Object.expanded6 = bpy.props.BoolProperty(default=False)


def unregister():
    for blender_class in blender_classes:
        bpy.utils.unregister_class(blender_class)
    del bpy.types.Scene.sunfire_sky_name
    del bpy.types.Object.expanded1
    del bpy.types.Object.expanded2
    del bpy.types.Object.expanded3
    del bpy.types.Object.expanded4
    del bpy.types.Object.expanded5
    del bpy.types.Object.expanded6

if __name__ == "__main__":
    register()
